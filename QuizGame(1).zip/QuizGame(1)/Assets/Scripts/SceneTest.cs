using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTest : MonoBehaviour
{


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void IncrementScore()
    {
        GameManager.instance.score++;
    }

    public void ResetScore()
    {
        GameManager.instance.score = 0;
    }

    public void GoToFirst()
    {
        SceneManager.LoadScene("SampleScene");
    }

    public void GoToNewScene()
    {
        SceneManager.LoadScene("Scene2");
    }

    public void GoToScene3()
    {
        SceneManager.LoadScene("Scene3");
    }

    public void GoToEnd()
    {
        SceneManager.LoadScene("Scene4");
    }
}
