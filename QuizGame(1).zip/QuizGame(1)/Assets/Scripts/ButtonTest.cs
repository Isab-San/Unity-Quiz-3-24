using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.SceneManagement;

public class ButtonTest : MonoBehaviour
{
    /*public static GameManager instance;

    public int score = 0;*/

    public Text myText;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    /*public void ChangeText()
    {
        myText.text = "My new Text";
    }
    */

    public void CorrectAnswer()
    {
        myText.text = "That is correct!";
        //GameManager.instance.score++;
        //SceneManager.LoadScene("Scene3");
    }

    public void WrongAnswer()
    {
        myText.text = "That is incorrect!";
        //SceneManager.LoadScene("Scene3");
    }
}
