using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    //public Text scoreText;

    public int score = 0;
    
    // Start is called before the first frame update
    void Start()
    {
        //score = GetComponent<Text>();
        //scoreText.text = score.ToString() + " Points";
        if(instance == null)
        {
            instance = this;
        }

        else
        {
            Destroy(gameObject);
        }

        DontDestroyOnLoad(gameObject);
    }

    // Update is called once per frame
    void Update()
    {
        //score.text = "Answered: " + scoreValue;
    }
}
